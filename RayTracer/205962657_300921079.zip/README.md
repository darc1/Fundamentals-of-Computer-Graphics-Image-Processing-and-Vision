Rober Haiek 205962657 Chen Dar 300921079 TAU Fundamentals of Computer Graphics, Image Processing, and Vision (0368-3236.01) 2019-2020

To run notebook, from the archive root run:

```jupyter notebook 205962657_300921079_notebook.ipynb```__